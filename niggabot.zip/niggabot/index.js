const {
  Client,
  GatewayIntentBits,
  Partials,
  Collection,
} = require("discord.js");
const { Guilds, GuildMembers, GuildMessages, MessageContent } = GatewayIntentBits;
const { User, Message, GuildMember, ThreadMember } = Partials;


const client = new Client({
  intents: [Guilds, GuildMembers, GuildMessages, MessageContent],
  partials: [User, Message, GuildMember, ThreadMember],
});

const { loadEvents } = require("./Handlers/eventHandler");




client.config = require("./config.json");
client.commands = new Collection();
client.events = new Collection();
client.subCommands = new Collection();
client.guildConfig = new Collection();

const { connect } = require("mongoose");
connect(client.config.DatabaseURL, {
}).then(() => console.log("Connected to database!"));

loadEvents(client);

const { loadConfig } = require('./Functions/configLoader')
loadConfig(client);

client.login(client.config.Token)
