const {
  SlashCommandBuilder,
  PermissionFlagsBits,
} = require("discord.js");


module.exports = {
  developer: true,
  data: new SlashCommandBuilder()
    .setName("reload")
    .setDescription("Reloads your commands/events")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((options) =>
      options.setName("events").setDescription("Reloads your events")
    )
    .addSubcommand((options) =>
      options.setName("commands").setDescription("Reloads your commands")
    ),
};
