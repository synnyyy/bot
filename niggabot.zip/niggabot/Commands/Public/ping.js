const {
  chatInputApplicationCommandMention,
  SlashCommandBuilder,
} = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Replies with client latency."),

  /*
   * @param {ChatInputCommandInteraction} interaction
   */
  async execute(interaction, client) {
    await interaction.reply({
      content: `w.\nClient latency: ${client.ws.ping}ms`,
      ephemeral: true,
    });
  },
};
