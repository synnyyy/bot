const { chatInputApplicationCommandMention, SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('baller')
        .setDescription('send baller hehea'),
    /**
     * @param {chatInputCommandInteracrion} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        await interaction.reply({ content: 'Baller: https://tenor.com/view/roblox-baller-roblox-baller-baller-guy-ballers-gif-26937843' })
    }
}