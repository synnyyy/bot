const { loadCommands } = require('../../Handlers/commandHandler');

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        console.log(`Logged in as ${client.user.tag}!`);
        loadCommands(client);
        await client.user.setActivity('a game', { type: 'PLAYING' })
    }
}