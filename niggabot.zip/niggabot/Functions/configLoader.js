const configDatabase = require('../Schemas/Memberlog')

async function loadConfig(client) {
    (await configDatabase.find()).forEach((doc) => {
        client.guildConfig.set(doc.Guild, {
            logChannel: doc.logChannel,
            memberRole: doc.memberRole,
            botRole: doc.botRole,
        });
    });

    return console.log('Success! Loaded Guild configs to the collectoion!')
}

module.exports = { loadConfig };